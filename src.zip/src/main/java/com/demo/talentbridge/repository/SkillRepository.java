//package com.demo.talentbridge.repository;
//
//import com.demo.talentbridge.entity.Skill;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//import java.util.Optional;
//
//@Repository
//public interface SkillRepository extends JpaRepository<Skill, Long> {
//    Optional<Skill> findByName(String name);
//    boolean existsByName(String name);
//}
